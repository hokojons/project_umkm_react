import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user' | 'umkm';
}

interface AuthContextType {
  user: User | null;
  accessToken: string | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, role?: 'admin' | 'user' | 'umkm') => Promise<void>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('pasar_umkm_current_user');
    const savedToken = localStorage.getItem('pasar_umkm_access_token');
    
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      setAccessToken(savedToken);
    }
    
    setIsLoading(false);
  }, []);

  const signIn = async (email: string, password: string) => {
    // Get all users from localStorage
    const localUsers = localStorage.getItem('pasar_umkm_users');
    const localPasswords = localStorage.getItem('pasar_umkm_passwords');
    
    if (!localUsers || !localPasswords) {
      throw new Error('Akun tidak ditemukan. Silakan daftar terlebih dahulu.');
    }
    
    const users: User[] = JSON.parse(localUsers);
    const passwords: Record<string, string> = JSON.parse(localPasswords);
    
    // Find user by email
    const foundUser = users.find(u => u.email === email);
    
    if (!foundUser) {
      throw new Error('Email atau password salah');
    }
    
    // Check password
    if (passwords[email] !== password) {
      throw new Error('Email atau password salah');
    }
    
    // Set user and token
    const token = `token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setUser(foundUser);
    setAccessToken(token);
    
    // Save to localStorage
    localStorage.setItem('pasar_umkm_current_user', JSON.stringify(foundUser));
    localStorage.setItem('pasar_umkm_access_token', token);
  };

  const signUp = async (email: string, password: string, name: string, role?: 'admin' | 'user' | 'umkm') => {
    // Get existing users
    const localUsers = localStorage.getItem('pasar_umkm_users');
    const localPasswords = localStorage.getItem('pasar_umkm_passwords');
    
    const users: User[] = localUsers ? JSON.parse(localUsers) : [];
    const passwords: Record<string, string> = localPasswords ? JSON.parse(localPasswords) : {};
    
    // Check if email already exists
    if (users.some(u => u.email === email)) {
      throw new Error('Email sudah terdaftar');
    }
    
    // Create new user
    const newUser: User = {
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      email,
      name,
      role: role || 'user'
    };
    
    // Save user and password
    users.push(newUser);
    passwords[email] = password;
    
    localStorage.setItem('pasar_umkm_users', JSON.stringify(users));
    localStorage.setItem('pasar_umkm_passwords', JSON.stringify(passwords));
    
    // Auto sign in
    await signIn(email, password);
  };

  const signOut = async () => {
    setUser(null);
    setAccessToken(null);
    localStorage.removeItem('pasar_umkm_current_user');
    localStorage.removeItem('pasar_umkm_access_token');
  };

  const refreshUser = async () => {
    // Reload user from localStorage
    const savedUser = localStorage.getItem('pasar_umkm_current_user');
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      
      // Get updated user data from users list
      const localUsers = localStorage.getItem('pasar_umkm_users');
      if (localUsers) {
        const users: User[] = JSON.parse(localUsers);
        const updatedUser = users.find(u => u.id === userData.id);
        if (updatedUser) {
          setUser(updatedUser);
          localStorage.setItem('pasar_umkm_current_user', JSON.stringify(updatedUser));
        }
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{ user, accessToken, isLoading, signIn, signUp, signOut, refreshUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
