import { useState, useEffect } from 'react';
import { X, Plus, Edit, Trash2, Store as StoreIcon, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner@2.0.3';

interface UMKMDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onDataUpdate?: () => void;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  category: string;
  businessId: string;
  ownerId?: string;
}

interface Business {
  id: string;
  name: string;
  owner: string;
  description: string;
  image: string;
  category: string;
  rating: number;
  ownerId?: string;
  userId?: string;
}

export function UMKMDashboard({ isOpen, onClose, onDataUpdate }: UMKMDashboardProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'businesses' | 'products'>('businesses');
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (isOpen && user?.role === 'umkm') {
      fetchData();
    }
  }, [isOpen, activeTab, user]);

  const fetchData = () => {
    if (!user) return;

    try {
      if (activeTab === 'businesses') {
        const localBusinesses = localStorage.getItem('pasar_umkm_businesses');
        if (localBusinesses) {
          const allBusinesses = JSON.parse(localBusinesses);
          // Filter by userId or by user email if userId not available
          const myBusinesses = allBusinesses.filter((b: Business) => 
            b.userId === user.id || b.ownerId === user.id
          );
          setBusinesses(myBusinesses);
        } else {
          setBusinesses([]);
        }
      } else {
        const localProducts = localStorage.getItem('pasar_umkm_products');
        if (localProducts) {
          const allProducts = JSON.parse(localProducts);
          // Get all businesses owned by user
          const localBusinesses = localStorage.getItem('pasar_umkm_businesses');
          const myBusinessIds = localBusinesses 
            ? JSON.parse(localBusinesses)
                .filter((b: Business) => b.userId === user.id || b.ownerId === user.id)
                .map((b: Business) => b.id)
            : [];
          
          // Filter products that belong to user's businesses
          const myProducts = allProducts.filter((p: Product) => 
            myBusinessIds.includes(p.businessId) || p.ownerId === user.id
          );
          setProducts(myProducts);
        } else {
          setProducts([]);
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Gagal memuat data');
    }
  };

  const handleDeleteBusiness = (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus bisnis ini? Semua produk terkait juga akan dihapus.')) {
      return;
    }

    try {
      const localBusinesses = localStorage.getItem('pasar_umkm_businesses');
      if (localBusinesses) {
        const allBusinesses = JSON.parse(localBusinesses);
        const updatedBusinesses = allBusinesses.filter((b: Business) => b.id !== id);
        localStorage.setItem('pasar_umkm_businesses', JSON.stringify(updatedBusinesses));
      }

      // Also delete related products
      const localProducts = localStorage.getItem('pasar_umkm_products');
      if (localProducts) {
        const allProducts = JSON.parse(localProducts);
        const updatedProducts = allProducts.filter((p: Product) => p.businessId !== id);
        localStorage.setItem('pasar_umkm_products', JSON.stringify(updatedProducts));
      }

      toast.success('Bisnis berhasil dihapus');
      fetchData();
      if (onDataUpdate) onDataUpdate();
    } catch (error) {
      console.error('Error deleting business:', error);
      toast.error('Gagal menghapus bisnis');
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus produk ini?')) {
      return;
    }

    try {
      const localProducts = localStorage.getItem('pasar_umkm_products');
      if (localProducts) {
        const allProducts = JSON.parse(localProducts);
        const updatedProducts = allProducts.filter((p: Product) => p.id !== id);
        localStorage.setItem('pasar_umkm_products', JSON.stringify(updatedProducts));
      }

      toast.success('Produk berhasil dihapus');
      fetchData();
      if (onDataUpdate) onDataUpdate();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Gagal menghapus produk');
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between z-10 rounded-t-2xl">
          <div>
            <h2 className="mb-1">Dashboard UMKM</h2>
            <p className="text-gray-600 text-sm">Kelola toko dan produk Anda</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="size-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setActiveTab('businesses')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${
                activeTab === 'businesses'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <StoreIcon className="size-5" />
              Toko Saya ({businesses.length})
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${
                activeTab === 'products'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Package className="size-5" />
              Produk Saya ({products.length})
            </button>
          </div>

          {/* Content */}
          {activeTab === 'businesses' ? (
            <div>
              {businesses.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <StoreIcon className="size-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 mb-4">
                    Anda belum memiliki toko yang terdaftar
                  </p>
                  <p className="text-sm text-gray-500">
                    Gunakan menu "Ajukan Toko UMKM" untuk mendaftarkan toko Anda
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {businesses.map((business) => (
                    <div key={business.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex gap-4">
                        <img
                          src={business.image}
                          alt={business.name}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3 className="mb-1">{business.name}</h3>
                          <p className="text-sm text-gray-600 mb-2">{business.description}</p>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs rounded">
                              {business.category}
                            </span>
                            <span className="text-sm text-gray-500">⭐ {business.rating}</span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <button
                            onClick={() => handleDeleteBusiness(business.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Hapus"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div>
              {products.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <Package className="size-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 mb-4">
                    Anda belum memiliki produk yang terdaftar
                  </p>
                  <p className="text-sm text-gray-500">
                    Produk akan muncul di sini setelah toko Anda disetujui oleh admin
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {products.map((product) => (
                    <div key={product.id} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                      {product.image && (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-48 object-cover"
                        />
                      )}
                      <div className="p-4">
                        <h4 className="mb-1">{product.name}</h4>
                        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{product.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-indigo-600 font-medium">{formatCurrency(product.price)}</span>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleDeleteProduct(product.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Hapus"
                            >
                              <Trash2 className="size-4" />
                            </button>
                          </div>
                        </div>
                        <span className="inline-block mt-2 px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                          {product.category}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Info Box */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Catatan:</strong> Untuk menambah toko atau produk baru, gunakan menu "Ajukan Toko UMKM". 
              Setelah disetujui admin, toko dan produk Anda akan muncul di marketplace.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}