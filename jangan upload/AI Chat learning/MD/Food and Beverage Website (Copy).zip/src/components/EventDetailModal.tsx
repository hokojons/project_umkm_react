import { Calendar, MapPin, X, Store, AlertCircle } from 'lucide-react';

interface Event {
  id: string;
  name: string;
  description: string;
  date: string;
  location: string;
  image?: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

interface EventDetailModalProps {
  event: Event;
  onClose: () => void;
  onApply?: () => void;
  userRole?: string;
  isLoggedIn: boolean;
}

export function EventDetailModal({ event, onClose, onApply, userRole, isLoggedIn }: EventDetailModalProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      upcoming: { text: 'Akan Datang', className: 'bg-blue-100 text-blue-700' },
      ongoing: { text: 'Sedang Berlangsung', className: 'bg-green-100 text-green-700' },
      completed: { text: 'Selesai', className: 'bg-gray-100 text-gray-700' }
    };
    return badges[status as keyof typeof badges] || badges.upcoming;
  };

  const statusBadge = getStatusBadge(event.status);
  const canApply = isLoggedIn && userRole === 'umkm' && event.status !== 'completed';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header Image */}
        {event.image && (
          <div className="relative h-64 md:h-80">
            <img 
              src={event.image} 
              alt={event.name}
              className="w-full h-full object-cover rounded-t-2xl"
            />
            <button
              onClick={onClose}
              className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100 transition-colors shadow-lg"
            >
              <X className="size-6" />
            </button>
            <div className="absolute bottom-4 left-4">
              <span className={`px-4 py-2 rounded-full text-sm font-medium ${statusBadge.className}`}>
                {statusBadge.text}
              </span>
            </div>
          </div>
        )}

        {/* Close button if no image */}
        {!event.image && (
          <div className="flex justify-end p-4">
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="size-6" />
            </button>
          </div>
        )}

        {/* Content */}
        <div className="p-6 md:p-8">
          {/* Title and Status */}
          <div className="mb-6">
            <h2 className="mb-3">{event.name}</h2>
            {!event.image && (
              <span className={`inline-block px-4 py-2 rounded-full text-sm font-medium ${statusBadge.className}`}>
                {statusBadge.text}
              </span>
            )}
          </div>

          {/* Event Info */}
          <div className="space-y-4 mb-8">
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <Calendar className="size-5 text-indigo-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-gray-600 mb-1">Tanggal</p>
                <p className="font-medium">{formatDate(event.date)}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <MapPin className="size-5 text-indigo-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-gray-600 mb-1">Lokasi</p>
                <p className="font-medium">{event.location}</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="mb-8">
            <h3 className="mb-3">Tentang Event</h3>
            <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{event.description}</p>
          </div>

          {/* Benefits for UMKM */}
          <div className="mb-8 p-6 bg-indigo-50 rounded-lg">
            <h3 className="mb-4 flex items-center gap-2">
              <Store className="size-5 text-indigo-600" />
              Keuntungan Berjualan di Event Ini
            </h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>Kesempatan bertemu langsung dengan pelanggan potensial</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>Meningkatkan brand awareness produk UMKM Anda</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>Networking dengan pelaku UMKM lainnya</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>Booth dan promosi gratis dari Pasar UMKM</span>
              </li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            {canApply ? (
              <button
                onClick={onApply}
                className="w-full bg-indigo-600 text-white py-4 rounded-lg hover:bg-indigo-700 transition-colors font-medium flex items-center justify-center gap-2"
              >
                <Store className="size-5" />
                Ajukan Berjualan di Event Ini
              </button>
            ) : !isLoggedIn ? (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="size-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-900 mb-1">Login Diperlukan</p>
                    <p className="text-sm text-amber-700">
                      Silakan login terlebih dahulu untuk mengajukan berjualan di event ini
                    </p>
                  </div>
                </div>
              </div>
            ) : userRole !== 'umkm' ? (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="size-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-900 mb-1">Hanya untuk UMKM</p>
                    <p className="text-sm text-amber-700">
                      Hanya akun dengan role UMKM yang dapat mengajukan berjualan di event ini. 
                      {userRole === 'user' && ' Silakan ajukan upgrade ke UMKM terlebih dahulu.'}
                    </p>
                  </div>
                </div>
              </div>
            ) : event.status === 'completed' ? (
              <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="size-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-gray-900 mb-1">Event Telah Selesai</p>
                    <p className="text-sm text-gray-700">
                      Event ini sudah selesai. Nantikan event-event menarik lainnya!
                    </p>
                  </div>
                </div>
              </div>
            ) : null}

            <button
              onClick={onClose}
              className="w-full bg-white border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
