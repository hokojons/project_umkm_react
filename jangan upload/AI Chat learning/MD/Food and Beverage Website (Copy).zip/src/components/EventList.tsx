import { useState, useEffect } from 'react';
import { EventCard } from './EventCard';
import { EventDetailModal } from './EventDetailModal';
import { Calendar } from 'lucide-react';

interface Event {
  id: string;
  name: string;
  description: string;
  date: string;
  location: string;
  image?: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

interface EventListProps {
  onApplyToEvent?: (eventId: string) => void;
  showApplyButton?: boolean;
  userRole?: string;
  isLoggedIn?: boolean;
}

export function EventList({ onApplyToEvent, showApplyButton = false, userRole, isLoggedIn = false }: EventListProps) {
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'ongoing' | 'completed'>('all');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = () => {
    // Langsung pakai localStorage saja
    const localEvents = localStorage.getItem('pasar_umkm_events');
    if (localEvents) {
      setEvents(JSON.parse(localEvents));
    }
    setIsLoading(false);
  };

  const filteredEvents = events.filter(event => {
    if (filter === 'all') return true;
    return event.status === filter;
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center">
            <p className="text-gray-500">Memuat events...</p>
          </div>
        </div>
      </section>
    );
  }

  if (events.length === 0) {
    return null; // Don't show section if no events
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4">Event & Bazaar UMKM</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Jangan lewatkan kesempatan untuk berpartisipasi dalam event dan bazaar yang kami selenggarakan
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex justify-center gap-3 mb-8">
          <button
            onClick={() => setFilter('all')}
            className={`px-6 py-2 rounded-full transition-colors ${
              filter === 'all'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Semua ({events.length})
          </button>
          <button
            onClick={() => setFilter('upcoming')}
            className={`px-6 py-2 rounded-full transition-colors ${
              filter === 'upcoming'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Akan Datang ({events.filter(e => e.status === 'upcoming').length})
          </button>
          <button
            onClick={() => setFilter('ongoing')}
            className={`px-6 py-2 rounded-full transition-colors ${
              filter === 'ongoing'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Berlangsung ({events.filter(e => e.status === 'ongoing').length})
          </button>
        </div>

        {filteredEvents.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg">
            <Calendar className="size-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">Tidak ada event {filter !== 'all' && `yang ${filter === 'upcoming' ? 'akan datang' : 'sedang berlangsung'}`}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onApply={onApplyToEvent}
                onClick={setSelectedEvent}
                showApplyButton={showApplyButton}
                userRole={userRole}
              />
            ))}
          </div>
        )}
      </div>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onApply={() => {
            if (onApplyToEvent) {
              onApplyToEvent(selectedEvent.id);
            }
            setSelectedEvent(null);
          }}
          userRole={userRole}
          isLoggedIn={isLoggedIn}
        />
      )}
    </section>
  );
}