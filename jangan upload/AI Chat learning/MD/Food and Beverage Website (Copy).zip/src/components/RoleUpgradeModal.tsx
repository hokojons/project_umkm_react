import { useState } from 'react';
import { X, Award } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner@2.0.3';

interface RoleUpgradeModalProps {
  onClose: () => void;
  onSuccess?: () => void;
}

export default function RoleUpgradeModal({ onClose, onSuccess }: RoleUpgradeModalProps) {
  const { accessToken, refreshUser } = useAuth();
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!reason.trim()) {
      toast.error('Mohon jelaskan alasan permintaan upgrade role');
      return;
    }

    setLoading(true);

    try {
      // Save to localStorage
      const localRequests = localStorage.getItem('pasar_umkm_role_requests');
      const requests = localRequests ? JSON.parse(localRequests) : [];
      
      const currentUser = localStorage.getItem('pasar_umkm_current_user');
      if (!currentUser) {
        throw new Error('User tidak ditemukan');
      }
      
      const user = JSON.parse(currentUser);
      
      const newRequest = {
        id: `req_${Date.now()}`,
        userId: user.id,
        userEmail: user.email,
        userName: user.name,
        requestedRole: 'umkm',
        currentRole: user.role,
        reason,
        status: 'pending',
        submittedAt: new Date().toISOString()
      };
      
      requests.push(newRequest);
      localStorage.setItem('pasar_umkm_role_requests', JSON.stringify(requests));

      toast.success('Permintaan upgrade role berhasil diajukan! Tunggu persetujuan admin.');
      onSuccess?.();
      onClose();
    } catch (error) {
      console.error('Error submitting role upgrade:', error);
      toast.error(error instanceof Error ? error.message : 'Gagal mengajukan permintaan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <h2 className="text-indigo-900">Ajukan Upgrade ke Role UMKM</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
            <h3 className="text-indigo-900 mb-2">Manfaat Role UMKM</h3>
            <ul className="text-sm text-indigo-700 space-y-1">
              <li>• Dapat menambah toko/stan UMKM sendiri</li>
              <li>• Dapat menambah, edit, dan hapus produk Anda</li>
              <li>• Tetap dapat berbelanja dari UMKM lain</li>
              <li>• Mengelola bisnis secara mandiri</li>
            </ul>
          </div>

          <div className="space-y-2">
            <label htmlFor="reason" className="block text-sm">
              Alasan Permintaan <span className="text-red-500">*</span>
            </label>
            <textarea
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Jelaskan mengapa Anda ingin menjadi penjual UMKM di marketplace ini..."
              rows={5}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <p className="text-sm text-gray-500">
              Jelaskan secara singkat tentang bisnis UMKM yang ingin Anda jalankan
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              disabled={loading}
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={loading}
            >
              {loading ? 'Mengajukan...' : 'Ajukan Permintaan'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}