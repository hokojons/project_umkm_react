import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Calendar, MapPin, Users, Plus, Edit2, Trash2, X, Eye } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Event {
  id: string;
  name: string;
  description: string;
  date: string;
  location: string;
  image?: string;
  status: 'upcoming' | 'ongoing' | 'completed';
  createdAt: string;
}

interface EventApplication {
  id: string;
  eventId: string;
  umkmId: string;
  umkmEmail: string;
  umkmName: string;
  businessId: string;
  products: Array<{
    id: string;
    name: string;
    price: number;
    image: string;
  }>;
  notes?: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  adminNotes?: string;
}

interface EventManagementProps {
  onClose?: () => void;
}

export function EventManagement({ onClose }: EventManagementProps) {
  const { accessToken } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showEventForm, setShowEventForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [selectedEventForApplications, setSelectedEventForApplications] = useState<Event | null>(null);
  const [applications, setApplications] = useState<EventApplication[]>([]);
  const [isLoadingApplications, setIsLoadingApplications] = useState(false);

  const [eventForm, setEventForm] = useState({
    name: '',
    description: '',
    date: '',
    location: '',
    image: '',
    status: 'upcoming' as 'upcoming' | 'ongoing' | 'completed'
  });

  const [dateForm, setDateForm] = useState({
    day: '',
    month: '',
    year: ''
  });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = () => {
    // Langsung pakai localStorage saja
    const localEvents = localStorage.getItem('pasar_umkm_events');
    if (localEvents) {
      setEvents(JSON.parse(localEvents));
    }
    setIsLoading(false);
  };

  const fetchApplicationsForEvent = (eventId: string) => {
    setIsLoadingApplications(true);
    // Pakai localStorage saja
    const localApplications = localStorage.getItem('pasar_umkm_event_applications');
    if (localApplications) {
      const allApplications = JSON.parse(localApplications);
      const eventApplications = allApplications.filter((app: EventApplication) => app.eventId === eventId);
      setApplications(eventApplications);
    }
    setIsLoadingApplications(false);
  };

  const handleSubmitEvent = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!eventForm.name || !eventForm.description || !eventForm.date || !eventForm.location) {
      toast.error('Semua field wajib diisi');
      return;
    }

    // Pakai localStorage saja
    const localEvents = localStorage.getItem('pasar_umkm_events');
    const currentEvents = localEvents ? JSON.parse(localEvents) : [];

    if (editingEvent) {
      // Update existing event
      const updatedEvents = currentEvents.map((evt: Event) =>
        evt.id === editingEvent.id
          ? { ...eventForm, id: editingEvent.id, createdAt: editingEvent.createdAt }
          : evt
      );
      localStorage.setItem('pasar_umkm_events', JSON.stringify(updatedEvents));
      setEvents(updatedEvents);
      toast.success('Event berhasil diupdate');
    } else {
      // Create new event
      const newEvent = {
        ...eventForm,
        id: `event_${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      const updatedEvents = [...currentEvents, newEvent];
      localStorage.setItem('pasar_umkm_events', JSON.stringify(updatedEvents));
      setEvents(updatedEvents);
      toast.success('Event berhasil dibuat');
    }

    setShowEventForm(false);
    setEditingEvent(null);
    setEventForm({
      name: '',
      description: '',
      date: '',
      location: '',
      image: '',
      status: 'upcoming'
    });
    setDateForm({
      day: '',
      month: '',
      year: ''
    });
  };

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event);
    
    // Parse existing date
    const dateObj = new Date(event.date);
    setDateForm({
      day: dateObj.getDate().toString(),
      month: (dateObj.getMonth() + 1).toString(),
      year: dateObj.getFullYear().toString()
    });
    
    setEventForm({
      name: event.name,
      description: event.description,
      date: event.date,
      location: event.location,
      image: event.image || '',
      status: event.status
    });
    setShowEventForm(true);
  };

  const handleDeleteEvent = (eventId: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus event ini? Semua aplikasi untuk event ini juga akan dihapus.')) {
      return;
    }

    // Pakai localStorage saja
    const localEvents = localStorage.getItem('pasar_umkm_events');
    if (localEvents) {
      const currentEvents = JSON.parse(localEvents);
      const updatedEvents = currentEvents.filter((evt: Event) => evt.id !== eventId);
      localStorage.setItem('pasar_umkm_events', JSON.stringify(updatedEvents));
      setEvents(updatedEvents);
      toast.success('Event berhasil dihapus');
    }
  };

  const handleViewApplications = (event: Event) => {
    setSelectedEventForApplications(event);
    fetchApplicationsForEvent(event.id);
  };

  const handleUpdateApplicationStatus = (applicationId: string, status: 'approved' | 'rejected', adminNotes?: string) => {
    // Pakai localStorage saja
    const localApplications = localStorage.getItem('pasar_umkm_event_applications');
    if (localApplications) {
      const allApplications = JSON.parse(localApplications);
      const updatedApplications = allApplications.map((app: EventApplication) =>
        app.id === applicationId
          ? { ...app, status, adminNotes }
          : app
      );
      localStorage.setItem('pasar_umkm_event_applications', JSON.stringify(updatedApplications));
      toast.success(status === 'approved' ? 'Aplikasi disetujui' : 'Aplikasi ditolak');
      if (selectedEventForApplications) {
        fetchApplicationsForEvent(selectedEventForApplications.id);
      }
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (selectedEventForApplications) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="mb-2">Aplikasi Event: {selectedEventForApplications.name}</h2>
            <p className="text-gray-600">
              {applications.length} aplikasi • {applications.filter(a => a.status === 'pending').length} menunggu review
            </p>
          </div>
          <button
            onClick={() => {
              setSelectedEventForApplications(null);
              setApplications([]);
            }}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="size-6" />
          </button>
        </div>

        {isLoadingApplications ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Memuat aplikasi...</p>
          </div>
        ) : applications.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <Users className="size-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">Belum ada aplikasi untuk event ini</p>
          </div>
        ) : (
          <div className="space-y-4">
            {applications.map((application) => (
              <div key={application.id} className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="mb-1">{application.umkmName}</h3>
                    <p className="text-sm text-gray-600">{application.umkmEmail}</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Diajukan: {formatDate(application.submittedAt)}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    application.status === 'approved' 
                      ? 'bg-green-100 text-green-700'
                      : application.status === 'rejected'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {application.status === 'approved' ? 'Disetujui' : application.status === 'rejected' ? 'Ditolak' : 'Menunggu'}
                  </span>
                </div>

                {application.notes && (
                  <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm">
                      <span className="font-medium">Catatan: </span>
                      {application.notes}
                    </p>
                  </div>
                )}

                <div className="mb-4">
                  <h4 className="text-sm font-medium mb-2">Produk yang akan dijual ({application.products.length}):</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {application.products.map((product) => (
                      <div key={product.id} className="border border-gray-200 rounded-lg p-3">
                        {product.image && (
                          <img 
                            src={product.image} 
                            alt={product.name}
                            className="w-full h-24 object-cover rounded mb-2"
                          />
                        )}
                        <p className="text-sm font-medium truncate">{product.name}</p>
                        <p className="text-sm text-indigo-600">{formatCurrency(product.price)}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {application.adminNotes && (
                  <div className="mb-4 p-3 bg-indigo-50 rounded-lg">
                    <p className="text-sm">
                      <span className="font-medium">Catatan Admin: </span>
                      {application.adminNotes}
                    </p>
                  </div>
                )}

                {application.status === 'pending' && (
                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <button
                      onClick={() => handleUpdateApplicationStatus(application.id, 'approved')}
                      className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                    >
                      Setujui
                    </button>
                    <button
                      onClick={() => {
                        const notes = prompt('Catatan penolakan (opsional):');
                        handleUpdateApplicationStatus(application.id, 'rejected', notes || undefined);
                      }}
                      className="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors"
                    >
                      Tolak
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (showEventForm) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2>{editingEvent ? 'Edit Event' : 'Buat Event Baru'}</h2>
          <button
            onClick={() => {
              setShowEventForm(false);
              setEditingEvent(null);
              setEventForm({
                name: '',
                description: '',
                date: '',
                location: '',
                image: '',
                status: 'upcoming'
              });
            }}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="size-6" />
          </button>
        </div>

        <form onSubmit={handleSubmitEvent} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Nama Event</label>
            <input
              type="text"
              required
              value={eventForm.name}
              onChange={(e) => setEventForm({ ...eventForm, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Festival Kuliner Nusantara"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Deskripsi</label>
            <textarea
              required
              value={eventForm.description}
              onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              rows={4}
              placeholder="Jelaskan tentang event ini..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Tanggal</label>
              <div className="grid grid-cols-3 gap-2">
                <select
                  required
                  value={dateForm.day}
                  onChange={(e) => {
                    setDateForm({ ...dateForm, day: e.target.value });
                    if (dateForm.month && dateForm.year && e.target.value) {
                      const formattedDate = `${dateForm.year}-${dateForm.month.padStart(2, '0')}-${e.target.value.padStart(2, '0')}`;
                      setEventForm({ ...eventForm, date: formattedDate });
                    }
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                >
                  <option value="">Hari</option>
                  {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
                
                <select
                  required
                  value={dateForm.month}
                  onChange={(e) => {
                    setDateForm({ ...dateForm, month: e.target.value });
                    if (dateForm.day && dateForm.year && e.target.value) {
                      const formattedDate = `${dateForm.year}-${e.target.value.padStart(2, '0')}-${dateForm.day.padStart(2, '0')}`;
                      setEventForm({ ...eventForm, date: formattedDate });
                    }
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                >
                  <option value="">Bulan</option>
                  <option value="1">Januari</option>
                  <option value="2">Februari</option>
                  <option value="3">Maret</option>
                  <option value="4">April</option>
                  <option value="5">Mei</option>
                  <option value="6">Juni</option>
                  <option value="7">Juli</option>
                  <option value="8">Agustus</option>
                  <option value="9">September</option>
                  <option value="10">Oktober</option>
                  <option value="11">November</option>
                  <option value="12">Desember</option>
                </select>
                
                <select
                  required
                  value={dateForm.year}
                  onChange={(e) => {
                    setDateForm({ ...dateForm, year: e.target.value });
                    if (dateForm.day && dateForm.month && e.target.value) {
                      const formattedDate = `${e.target.value}-${dateForm.month.padStart(2, '0')}-${dateForm.day.padStart(2, '0')}`;
                      setEventForm({ ...eventForm, date: formattedDate });
                    }
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                >
                  <option value="">Tahun</option>
                  {Array.from({ length: 10 }, (_, i) => new Date().getFullYear() + i).map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Status</label>
              <select
                value={eventForm.status}
                onChange={(e) => setEventForm({ ...eventForm, status: e.target.value as any })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="upcoming">Akan Datang</option>
                <option value="ongoing">Sedang Berlangsung</option>
                <option value="completed">Selesai</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Lokasi</label>
            <input
              type="text"
              required
              value={eventForm.location}
              onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Jakarta Convention Center"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">URL Gambar (opsional)</label>
            <input
              type="url"
              value={eventForm.image}
              onChange={(e) => setEventForm({ ...eventForm, image: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="https://example.com/event-image.jpg"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              {editingEvent ? 'Update Event' : 'Buat Event'}
            </button>
            <button
              type="button"
              onClick={() => {
                setShowEventForm(false);
                setEditingEvent(null);
              }}
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Batal
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="mb-2">Event Management</h2>
          <p className="text-gray-600">{events.length} event total</p>
        </div>
        <button
          onClick={() => setShowEventForm(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
        >
          <Plus className="size-5" />
          Buat Event
        </button>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <p className="text-gray-500">Memuat events...</p>
        </div>
      ) : events.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <Calendar className="size-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-500 mb-4">Belum ada event</p>
          <button
            onClick={() => setShowEventForm(true)}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Buat Event Pertama
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {events.map((event) => (
            <div key={event.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <div className="flex gap-4">
                {event.image && (
                  <img 
                    src={event.image} 
                    alt={event.name}
                    className="w-32 h-32 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="mb-1">{event.name}</h3>
                      <span className={`inline-block px-2 py-1 rounded text-xs ${
                        event.status === 'upcoming'
                          ? 'bg-blue-100 text-blue-700'
                          : event.status === 'ongoing'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {event.status === 'upcoming' ? 'Akan Datang' : event.status === 'ongoing' ? 'Berlangsung' : 'Selesai'}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleViewApplications(event)}
                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="Lihat Aplikasi"
                      >
                        <Eye className="size-5" />
                      </button>
                      <button
                        onClick={() => handleEditEvent(event)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="size-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteEvent(event.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Hapus"
                      >
                        <Trash2 className="size-5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{event.description}</p>
                  <div className="flex gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="size-4" />
                      {formatDate(event.date)}
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="size-4" />
                      {event.location}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}