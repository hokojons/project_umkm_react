import { FoodStand } from '../types';
import { Star, User, MessageCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface StandCardProps {
  stand: FoodStand;
  onClick: () => void;
}

export function StandCard({ stand, onClick }: StandCardProps) {
  return (
    <div
      onClick={onClick}
      data-stand-id={stand.id}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105"
    >
      <div className="relative h-48 overflow-hidden">
        <ImageWithFallback
          src={stand.image}
          alt={stand.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3 bg-white dark:bg-gray-800 px-3 py-1 rounded-full flex items-center gap-1 text-gray-900 dark:text-gray-100">
          <Star className="size-4 fill-yellow-400 text-yellow-400" />
          <span>{stand.rating}</span>
        </div>
        {stand.whatsapp && (
          <div className="absolute top-3 left-3 bg-green-600 px-2 py-1 rounded-full flex items-center gap-1 text-white">
            <MessageCircle className="size-3" />
            <span className="text-xs">Kontak</span>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="mb-2 text-gray-900 dark:text-gray-100">{stand.name}</h3>
        <div className="flex items-center gap-2 mb-2 text-gray-600 dark:text-gray-400">
          <User className="size-4" />
          <span className="text-sm">Pemilik: {stand.owner}</span>
        </div>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{stand.description}</p>
        <div className="flex items-center justify-between">
          <span className="inline-block bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-300 px-3 py-1 rounded-full text-sm">
            {stand.category}
          </span>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {stand.products.length} item produk
          </span>
        </div>
      </div>
    </div>
  );
}