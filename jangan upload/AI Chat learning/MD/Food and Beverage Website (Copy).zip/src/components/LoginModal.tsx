import { useState } from 'react';
import { X, Zap, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner@2.0.3';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LoginModal({ isOpen, onClose }: LoginModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [createAsAdmin, setCreateAsAdmin] = useState(false);
  const [isSettingUpAdmin, setIsSettingUpAdmin] = useState(false);
  const { signIn, signUp } = useAuth();

  if (!isOpen) return null;

  // Quick login untuk test user
  const quickLoginAsTestUser = async () => {
    setIsLoading(true);
    try {
      // Buat test user jika belum ada
      const localUsers = localStorage.getItem('pasar_umkm_users');
      const localPasswords = localStorage.getItem('pasar_umkm_passwords');
      
      const users = localUsers ? JSON.parse(localUsers) : [];
      const passwords = localPasswords ? JSON.parse(localPasswords) : {};
      
      // Cek apakah test user sudah ada
      const testUserExists = users.some((u: any) => u.email === 'testuser@pasarumkm.com');
      
      if (!testUserExists) {
        // Buat test user baru
        users.push({
          id: 'test_user_' + Date.now(),
          email: 'testuser@pasarumkm.com',
          name: 'Test User',
          role: 'user'
        });
        
        passwords['testuser@pasarumkm.com'] = 'test123';
        
        localStorage.setItem('pasar_umkm_users', JSON.stringify(users));
        localStorage.setItem('pasar_umkm_passwords', JSON.stringify(passwords));
      }
      
      // Login sebagai test user
      await signIn('testuser@pasarumkm.com', 'test123');
      toast.success('Login sebagai Test User berhasil!');
      onClose();
    } catch (error: any) {
      toast.error(error.message || 'Gagal login sebagai test user');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick login untuk UMKM test
  const quickLoginAsTestUMKM = async () => {
    setIsLoading(true);
    try {
      // Buat test UMKM user jika belum ada
      const localUsers = localStorage.getItem('pasar_umkm_users');
      const localPasswords = localStorage.getItem('pasar_umkm_passwords');
      
      const users = localUsers ? JSON.parse(localUsers) : [];
      const passwords = localPasswords ? JSON.parse(localPasswords) : {};
      
      // Cek apakah test UMKM sudah ada
      const testUMKMExists = users.some((u: any) => u.email === 'testumkm@pasarumkm.com');
      
      if (!testUMKMExists) {
        // Buat test UMKM baru
        users.push({
          id: 'test_umkm_' + Date.now(),
          email: 'testumkm@pasarumkm.com',
          name: 'Test UMKM',
          role: 'umkm'
        });
        
        passwords['testumkm@pasarumkm.com'] = 'umkm123';
        
        localStorage.setItem('pasar_umkm_users', JSON.stringify(users));
        localStorage.setItem('pasar_umkm_passwords', JSON.stringify(passwords));
      }
      
      // Login sebagai test UMKM
      await signIn('testumkm@pasarumkm.com', 'umkm123');
      toast.success('Login sebagai Test UMKM berhasil!');
      onClose();
    } catch (error: any) {
      toast.error(error.message || 'Gagal login sebagai test UMKM');
    } finally {
      setIsLoading(false);
    }
  };

  // Create random test user
  const createRandomTestUser = () => {
    const randomNum = Math.floor(Math.random() * 10000);
    const roles = ['user', 'umkm'];
    const randomRole = roles[Math.floor(Math.random() * roles.length)];
    
    setEmail(`testuser${randomNum}@test.com`);
    setPassword('test1234');
    setName(`Test User ${randomNum}`);
    setIsSignUp(true);
    setCreateAsAdmin(randomRole === 'admin');
    
    toast.info(`Test user data generated! Role: ${randomRole}`);
  };

  const handleSetupAdmin = () => {
    // Setup admin manually dengan mengisi kredensial
    setEmail('admin@pasarumkm.com');
    setPassword('admin123');
    
    const localUsers = localStorage.getItem('pasar_umkm_users');
    const localPasswords = localStorage.getItem('pasar_umkm_passwords');
    
    const users = localUsers ? JSON.parse(localUsers) : [];
    const passwords = localPasswords ? JSON.parse(localPasswords) : {};
    
    const adminExists = users.some((u: any) => u.email === 'admin@pasarumkm.com');
    
    if (!adminExists) {
      users.push({
        id: 'admin_' + Date.now(),
        email: 'admin@pasarumkm.com',
        name: 'Admin Pasar UMKM',
        role: 'admin'
      });
      
      passwords['admin@pasarumkm.com'] = 'admin123';
      
      localStorage.setItem('pasar_umkm_users', JSON.stringify(users));
      localStorage.setItem('pasar_umkm_passwords', JSON.stringify(passwords));
      
      toast.success('Akun admin berhasil dibuat! Silakan klik Masuk.');
    } else {
      toast.info('Akun admin sudah ada! Silakan klik Masuk.');
    }
  };

  const useDemoCredentials = () => {
    setEmail('admin@pasarumkm.com');
    setPassword('admin123');
    toast.info('Kredensial demo admin sudah terisi!');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isSignUp) {
        if (!name.trim()) {
          toast.error('Nama harus diisi');
          setIsLoading(false);
          return;
        }
        
        // Gunakan role dari checkbox createAsAdmin
        const role = createAsAdmin ? 'admin' : 'user';
        
        await signUp(email, password, name, role);
        toast.success(createAsAdmin ? 'Akun admin berhasil dibuat!' : 'Akun berhasil dibuat!');
      } else {
        await signIn(email, password);
        toast.success('Berhasil masuk!');
      }
      onClose();
      setEmail('');
      setPassword('');
      setName('');
      setCreateAsAdmin(false);
    } catch (error: any) {
      toast.error(error.message || 'Terjadi kesalahan');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = () => {
    setIsSignUp(!isSignUp);
    setEmail('');
    setPassword('');
    setName('');
    setCreateAsAdmin(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="size-5" />
        </button>

        <h2 className="mb-6">{isSignUp ? 'Daftar Akun' : 'Masuk'}</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <label className="block text-sm mb-2">Nama Lengkap</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
                placeholder="Masukkan nama lengkap"
              />
            </div>
          )}

          <div>
            <label className="block text-sm mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
              placeholder="nama@email.com"
            />
          </div>

          <div>
            <label className="block text-sm mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
              placeholder="Minimal 6 karakter"
              minLength={6}
            />
          </div>

          {isSignUp && (
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={createAsAdmin}
                onChange={(e) => setCreateAsAdmin(e.target.checked)}
                className="mr-2"
              />
              <label className="text-sm">Buat sebagai admin</label>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Memproses...' : isSignUp ? 'Daftar' : 'Masuk'}
          </button>
        </form>

        <div className="mt-6 text-center space-y-4">
          <button
            type="button"
            onClick={toggleMode}
            className="text-indigo-600 hover:underline text-sm"
          >
            {isSignUp ? 'Sudah punya akun? Masuk di sini' : 'Belum punya akun? Daftar di sini'}
          </button>
          
          {!isSignUp && (
            <div className="bg-indigo-50 rounded-lg p-4 border border-indigo-200 space-y-3">
              <p className="text-sm mb-2">
                <strong>Demo Admin:</strong>
              </p>
              <p className="text-sm text-indigo-900">
                <strong>Email:</strong> admin@pasarumkm.com
              </p>
              <p className="text-sm text-indigo-900 mb-3">
                <strong>Password:</strong> admin123
              </p>
              <button
                type="button"
                onClick={handleSetupAdmin}
                disabled={isSettingUpAdmin}
                className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSettingUpAdmin ? 'Membuat Akun Admin...' : '🔧 Setup Akun Admin (Klik Dulu)'}
              </button>
              <p className="text-xs text-indigo-700 text-center">
                Klik tombol di atas sekali, lalu login dengan kredensial di atas
              </p>
            </div>
          )}
        </div>

        <div className="mt-6 text-center space-y-4">
          <button
            type="button"
            onClick={quickLoginAsTestUser}
            disabled={isLoading}
            className="w-full bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Memproses...' : '⚡ Login sebagai Test User'}
          </button>
          <button
            type="button"
            onClick={quickLoginAsTestUMKM}
            disabled={isLoading}
            className="w-full bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Memproses...' : '⚡ Login sebagai Test UMKM'}
          </button>
          <button
            type="button"
            onClick={createRandomTestUser}
            disabled={isLoading}
            className="w-full bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Memproses...' : '⚡ Buat Test User Acak'}
          </button>
        </div>
      </div>
    </div>
  );
}