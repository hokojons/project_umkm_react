import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  onExplore: () => void;
}

export function HeroSection({ onExplore }: HeroSectionProps) {
  return (
    <section className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Main Featured Card */}
        <div className="md:col-span-1 bg-gradient-to-br from-indigo-600 to-indigo-700 dark:from-indigo-500 dark:to-indigo-600 rounded-2xl p-8 text-white flex flex-col justify-between min-h-[280px]">
          <div>
            <h2 className="mb-3 text-white">Dukung UMKM Lokal</h2>
            <p className="mb-6 opacity-90">
              Temukan produk berkualitas dari pelaku UMKM Indonesia. Setiap pembelian Anda membantu mengembangkan ekonomi lokal.
            </p>
          </div>
          <button
            onClick={onExplore}
            className="bg-white dark:bg-gray-100 text-indigo-600 dark:text-indigo-700 px-6 py-3 rounded-full hover:bg-indigo-50 dark:hover:bg-gray-200 transition-colors inline-flex items-center gap-2 w-fit"
          >
            Lihat Semua Produk
            <ArrowRight className="size-4" />
          </button>
        </div>

        {/* Featured Stand 1 */}
        <div className="relative rounded-2xl overflow-hidden group cursor-pointer h-[280px]">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1628774942553-bd4b553e7457?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwaGFuZGljcmFmdHN8ZW58MXx8fHwxNzY1MzQ0NDEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Handicrafts"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <h3 className="text-white mb-1">Kerajinan Tangan</h3>
            <p className="text-white/80 text-sm">Karya seni lokal Indonesia</p>
          </div>
        </div>

        {/* Featured Stand 2 */}
        <div className="relative rounded-2xl overflow-hidden group cursor-pointer h-[280px]">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1688487130731-cb5fb46201ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFsbCUyMGJ1c2luZXNzJTIwbWFya2V0fGVufDF8fHx8MTc2NTM0NDQwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Local Business"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <h3 className="text-white mb-1">Belanja Lokal</h3>
            <p className="text-white/80 text-sm">Kualitas terbaik dari pengrajin lokal</p>
          </div>
        </div>
      </div>
    </section>
  );
}