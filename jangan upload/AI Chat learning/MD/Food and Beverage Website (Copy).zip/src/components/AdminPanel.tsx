import { useState, useEffect } from 'react';
import { X, Store, Package, FileText, UserCog, Users, Calendar, Trash2, Check, XCircle, Filter, Search, Gift } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner@2.0.3';
import { foodStands } from '../data/stands';
import { EventManagement } from './EventManagement';
import { GiftPackageManagement } from './GiftPackageManagement';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onDataUpdate: () => void;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  category: string;
  businessId: string;
}

interface Business {
  id: string;
  name: string;
  owner: string;
  description: string;
  image: string;
  category: string;
  rating: number;
}

interface Submission {
  id: string;
  productName: string;
  description: string;
  price: number;
  category: string;
  image?: string;
  status: 'pending' | 'approved' | 'rejected';
  userName: string;
  userEmail: string;
  submittedAt: string;
  type: 'product' | 'business';
  business?: Business;
  products?: Product[];
  userId: string;
}

interface RoleUpgradeRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  requestedRole: 'umkm';
  currentRole: string;
  reason?: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  createdAt?: string;
}

export function AdminPanel({ isOpen, onClose, onDataUpdate }: AdminPanelProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'businesses' | 'products' | 'submissions' | 'roleRequests' | 'users' | 'events' | 'giftPackages'>('businesses');
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [roleRequests, setRoleRequests] = useState<RoleUpgradeRequest[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  useEffect(() => {
    if (isOpen && user?.role === 'admin') {
      fetchData();
    }
  }, [isOpen, activeTab]);

  const fetchData = () => {
    try {
      if (activeTab === 'businesses') {
        // Load dari foodStands
        const localBusinesses = foodStands.map(stand => ({
          id: stand.id,
          name: stand.name,
          owner: stand.owner,
          description: stand.description,
          image: stand.image,
          category: stand.category,
          rating: stand.rating
        }));

        // Merge dengan localStorage
        const savedBusinesses = localStorage.getItem('pasar_umkm_businesses');
        if (savedBusinesses) {
          const parsedBusinesses = JSON.parse(savedBusinesses);
          const mergedBusinesses = [...localBusinesses];
          parsedBusinesses.forEach((apiBusiness: Business) => {
            const index = mergedBusinesses.findIndex(b => b.id === apiBusiness.id);
            if (index >= 0) {
              mergedBusinesses[index] = apiBusiness;
            } else {
              mergedBusinesses.push(apiBusiness);
            }
          });
          setBusinesses(mergedBusinesses);
        } else {
          setBusinesses(localBusinesses);
        }
      } else if (activeTab === 'products') {
        // Load dari foodStands
        const localProducts: Product[] = [];
        foodStands.forEach(stand => {
          stand.products.forEach(product => {
            localProducts.push({
              id: product.id,
              name: product.name,
              description: product.description,
              price: product.price,
              image: product.image,
              category: product.category,
              businessId: stand.id
            });
          });
        });

        // Merge dengan localStorage
        const savedProducts = localStorage.getItem('pasar_umkm_products');
        if (savedProducts) {
          const parsedProducts = JSON.parse(savedProducts);
          const mergedProducts = [...localProducts];
          parsedProducts.forEach((apiProduct: Product) => {
            const index = mergedProducts.findIndex(p => p.id === apiProduct.id);
            if (index >= 0) {
              mergedProducts[index] = apiProduct;
            } else {
              mergedProducts.push(apiProduct);
            }
          });
          setProducts(mergedProducts);
        } else {
          setProducts(localProducts);
        }
      } else if (activeTab === 'submissions') {
        const savedSubmissions = localStorage.getItem('pasar_umkm_submissions');
        setSubmissions(savedSubmissions ? JSON.parse(savedSubmissions) : []);
      } else if (activeTab === 'roleRequests') {
        const savedRequests = localStorage.getItem('pasar_umkm_role_requests');
        setRoleRequests(savedRequests ? JSON.parse(savedRequests) : []);
      } else if (activeTab === 'users') {
        const savedUsers = localStorage.getItem('pasar_umkm_users');
        setUsers(savedUsers ? JSON.parse(savedUsers) : []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleDeleteBusiness = (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus UMKM ini?')) return;
    
    try {
      const savedBusinesses = localStorage.getItem('pasar_umkm_businesses');
      if (savedBusinesses) {
        const parsedBusinesses = JSON.parse(savedBusinesses);
        const updatedBusinesses = parsedBusinesses.filter((b: Business) => b.id !== id);
        localStorage.setItem('pasar_umkm_businesses', JSON.stringify(updatedBusinesses));
      }

      toast.success('UMKM berhasil dihapus');
      fetchData();
      onDataUpdate();
    } catch (error) {
      console.error('Error deleting business:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus produk ini?')) return;
    
    try {
      const savedProducts = localStorage.getItem('pasar_umkm_products');
      if (savedProducts) {
        const parsedProducts = JSON.parse(savedProducts);
        const updatedProducts = parsedProducts.filter((p: Product) => p.id !== id);
        localStorage.setItem('pasar_umkm_products', JSON.stringify(updatedProducts));
      }

      toast.success('Produk berhasil dihapus');
      fetchData();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleApproveSubmission = (submission: Submission) => {
    try {
      // Update submission status
      const savedSubmissions = localStorage.getItem('pasar_umkm_submissions');
      const parsedSubmissions = savedSubmissions ? JSON.parse(savedSubmissions) : [];
      const updatedSubmissions = parsedSubmissions.map((s: Submission) =>
        s.id === submission.id ? { ...s, status: 'approved' as const } : s
      );
      localStorage.setItem('pasar_umkm_submissions', JSON.stringify(updatedSubmissions));

      // Add to businesses if business submission
      if (submission.business && submission.products) {
        const savedBusinesses = localStorage.getItem('pasar_umkm_businesses');
        const businesses = savedBusinesses ? JSON.parse(savedBusinesses) : [];
        businesses.push(submission.business);
        localStorage.setItem('pasar_umkm_businesses', JSON.stringify(businesses));

        // Add products
        const savedProducts = localStorage.getItem('pasar_umkm_products');
        const products = savedProducts ? JSON.parse(savedProducts) : [];
        products.push(...submission.products);
        localStorage.setItem('pasar_umkm_products', JSON.stringify(products));
      }

      toast.success('Submission berhasil disetujui');
      fetchData();
      onDataUpdate();
    } catch (error) {
      console.error('Error approving submission:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleRejectSubmission = (id: string) => {
    try {
      const savedSubmissions = localStorage.getItem('pasar_umkm_submissions');
      const parsedSubmissions = savedSubmissions ? JSON.parse(savedSubmissions) : [];
      const updatedSubmissions = parsedSubmissions.map((s: Submission) =>
        s.id === id ? { ...s, status: 'rejected' as const } : s
      );
      localStorage.setItem('pasar_umkm_submissions', JSON.stringify(updatedSubmissions));

      toast.success('Submission berhasil ditolak');
      fetchData();
    } catch (error) {
      console.error('Error rejecting submission:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleApproveRoleRequest = (requestId: string) => {
    try {
      const savedRequests = localStorage.getItem('pasar_umkm_role_requests');
      const parsedRequests = savedRequests ? JSON.parse(savedRequests) : [];
      const request = parsedRequests.find((r: RoleUpgradeRequest) => r.id === requestId);
      
      if (!request) {
        toast.error('Request tidak ditemukan');
        return;
      }

      // Update request status
      const updatedRequests = parsedRequests.map((r: RoleUpgradeRequest) =>
        r.id === requestId ? { ...r, status: 'approved' as const } : r
      );
      localStorage.setItem('pasar_umkm_role_requests', JSON.stringify(updatedRequests));

      // Update user role
      const savedUsers = localStorage.getItem('pasar_umkm_users');
      const parsedUsers = savedUsers ? JSON.parse(savedUsers) : [];
      const updatedUsers = parsedUsers.map((u: User) =>
        u.id === request.userId ? { ...u, role: request.requestedRole } : u
      );
      localStorage.setItem('pasar_umkm_users', JSON.stringify(updatedUsers));

      // Update current user if it's the same user
      const currentUser = localStorage.getItem('pasar_umkm_current_user');
      if (currentUser) {
        const parsedCurrentUser = JSON.parse(currentUser);
        if (parsedCurrentUser.id === request.userId) {
          localStorage.setItem('pasar_umkm_current_user', JSON.stringify({
            ...parsedCurrentUser,
            role: request.requestedRole
          }));
        }
      }

      toast.success('Request role berhasil disetujui');
      fetchData();
    } catch (error) {
      console.error('Error approving role request:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleRejectRoleRequest = (requestId: string) => {
    try {
      const savedRequests = localStorage.getItem('pasar_umkm_role_requests');
      const parsedRequests = savedRequests ? JSON.parse(savedRequests) : [];
      const updatedRequests = parsedRequests.map((r: RoleUpgradeRequest) =>
        r.id === requestId ? { ...r, status: 'rejected' as const } : r
      );
      localStorage.setItem('pasar_umkm_role_requests', JSON.stringify(updatedRequests));

      toast.success('Request role berhasil ditolak');
      fetchData();
    } catch (error) {
      console.error('Error rejecting role request:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const handleUpdateUserRole = (userId: string, newRole: string) => {
    try {
      const savedUsers = localStorage.getItem('pasar_umkm_users');
      const parsedUsers = savedUsers ? JSON.parse(savedUsers) : [];
      const updatedUsers = parsedUsers.map((u: User) =>
        u.id === userId ? { ...u, role: newRole } : u
      );
      localStorage.setItem('pasar_umkm_users', JSON.stringify(updatedUsers));

      // Update current user if it's the same user
      const currentUser = localStorage.getItem('pasar_umkm_current_user');
      if (currentUser) {
        const parsedCurrentUser = JSON.parse(currentUser);
        if (parsedCurrentUser.id === userId) {
          localStorage.setItem('pasar_umkm_current_user', JSON.stringify({
            ...parsedCurrentUser,
            role: newRole
          }));
        }
      }

      toast.success('Role user berhasil diupdate');
      fetchData();
    } catch (error) {
      console.error('Error updating user role:', error);
      toast.error('Terjadi kesalahan');
    }
  };

  const toggleSelectItem = (id: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (!isOpen) return null;

  const menuItems = [
    { id: 'businesses', icon: Store, label: 'Bisnis UMKM' },
    { id: 'products', icon: Package, label: 'Produk' },
    { id: 'submissions', icon: FileText, label: 'Pengajuan Toko' },
    { id: 'roleRequests', icon: UserCog, label: 'Request Role' },
    { id: 'users', icon: Users, label: 'Manajemen User' },
    { id: 'events', icon: Calendar, label: 'Acara' },
    { id: 'giftPackages', icon: Gift, label: 'Paket Hadiah' }
  ];

  return (
    <div className="fixed inset-0 bg-white z-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-slate-800 text-white flex flex-col">
        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Store className="size-6" />
            </div>
            <div>
              <h2 className="text-white">Admin Panel</h2>
              <p className="text-xs text-slate-400">Pasar UMKM</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as any);
                setSelectedItems(new Set());
                setSearchQuery('');
                setFilterStatus('all');
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition-colors ${
                activeTab === item.id
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              <item.icon className="size-5" />
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
          >
            <X className="size-4" />
            <span className="text-sm">Tutup Panel</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-slate-50">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-8 py-4">
          <h2 className="text-slate-800 mb-1">
            {menuItems.find(m => m.id === activeTab)?.label}
          </h2>
          <p className="text-sm text-slate-500">
            Kelola data {menuItems.find(m => m.id === activeTab)?.label.toLowerCase()}
          </p>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-8">
          {activeTab === 'events' ? (
            <EventManagement />
          ) : activeTab === 'giftPackages' ? (
            <GiftPackageManagement />
          ) : (
            <>
              {/* Toolbar */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 mb-6">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    {activeTab === 'submissions' || activeTab === 'roleRequests' ? (
                      <div className="flex gap-2">
                        <button className="px-4 py-2 bg-slate-600 text-white rounded-lg text-sm hover:bg-slate-700 transition-colors flex items-center gap-2">
                          <Filter className="size-4" />
                          Filter
                        </button>
                      </div>
                    ) : null}
                  </div>

                  {/* Search */}
                  <div className="flex-1 max-w-md relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Cari data..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                  {activeTab === 'businesses' && (
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama UMKM</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Pemilik</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Kategori</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Rating</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {businesses
                          .filter(b => 
                            b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            b.owner.toLowerCase().includes(searchQuery.toLowerCase())
                          )
                          .map((business) => (
                          <tr key={business.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4 text-sm text-slate-600">{business.id.substring(0, 8)}...</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <img src={business.image} alt={business.name} className="w-10 h-10 rounded-lg object-cover" />
                                <span className="text-sm font-medium text-slate-900">{business.name}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-600">{business.owner}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs rounded">{business.category}</span>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-600">{business.rating}</td>
                            <td className="px-6 py-4">
                              <button
                                onClick={() => handleDeleteBusiness(business.id)}
                                className="text-rose-600 hover:text-rose-700"
                              >
                                <Trash2 className="size-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeTab === 'products' && (
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Produk</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Kategori</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Harga</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">UMKM</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {products
                          .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
                          .map((product) => (
                          <tr key={product.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                {product.image && (
                                  <img src={product.image} alt={product.name} className="w-10 h-10 rounded-lg object-cover" />
                                )}
                                <div>
                                  <p className="text-sm font-medium text-slate-900">{product.name}</p>
                                  <p className="text-xs text-slate-500">{product.description}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs rounded">{product.category}</span>
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-900">{formatCurrency(product.price)}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{businesses.find(b => b.id === product.businessId)?.name || '-'}</td>
                            <td className="px-6 py-4">
                              <button
                                onClick={() => handleDeleteProduct(product.id)}
                                className="text-rose-600 hover:text-rose-700"
                              >
                                <Trash2 className="size-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeTab === 'submissions' && (
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama Toko</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Pengaju</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Kategori</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {submissions
                          .filter(s => {
                            const matchesSearch = s.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                                 (s.business?.name || '').toLowerCase().includes(searchQuery.toLowerCase());
                            const matchesFilter = filterStatus === 'all' || s.status === filterStatus;
                            return matchesSearch && matchesFilter;
                          })
                          .map((submission) => (
                          <tr key={submission.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4 text-sm text-slate-600">{formatDate(submission.submittedAt)}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-900">{submission.business?.name || '-'}</td>
                            <td className="px-6 py-4">
                              <div>
                                <p className="text-sm text-slate-900">{submission.userName}</p>
                                <p className="text-xs text-slate-500">{submission.userEmail}</p>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs rounded">{submission.category}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`px-3 py-1 rounded-full text-xs ${
                                submission.status === 'approved' 
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : submission.status === 'rejected'
                                  ? 'bg-rose-100 text-rose-700'
                                  : 'bg-amber-100 text-amber-700'
                              }`}>
                                {submission.status === 'approved' ? 'Disetujui' : submission.status === 'rejected' ? 'Ditolak' : 'Pending'}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              {submission.status === 'pending' && (
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => handleApproveSubmission(submission)}
                                    className="text-emerald-600 hover:text-emerald-700"
                                    title="Setujui"
                                  >
                                    <Check className="size-4" />
                                  </button>
                                  <button
                                    onClick={() => handleRejectSubmission(submission.id)}
                                    className="text-rose-600 hover:text-rose-700"
                                    title="Tolak"
                                  >
                                    <XCircle className="size-4" />
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeTab === 'roleRequests' && (
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Role Saat Ini</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Role Diminta</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {roleRequests
                          .filter(r => {
                            const matchesSearch = r.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                                 r.userEmail.toLowerCase().includes(searchQuery.toLowerCase());
                            const matchesFilter = filterStatus === 'all' || r.status === filterStatus;
                            return matchesSearch && matchesFilter;
                          })
                          .map((request) => (
                          <tr key={request.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4 text-sm text-slate-600">{formatDate(request.submittedAt)}</td>
                            <td className="px-6 py-4 text-sm text-slate-900">{request.userName}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{request.userEmail}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded capitalize">{request.currentRole}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs rounded capitalize">{request.requestedRole}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`px-3 py-1 rounded-full text-xs ${
                                request.status === 'approved' 
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : request.status === 'rejected'
                                  ? 'bg-rose-100 text-rose-700'
                                  : 'bg-amber-100 text-amber-700'
                              }`}>
                                {request.status === 'approved' ? 'Disetujui' : request.status === 'rejected' ? 'Ditolak' : 'Pending'}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              {request.status === 'pending' && (
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => handleApproveRoleRequest(request.id)}
                                    className="text-emerald-600 hover:text-emerald-700"
                                    title="Setujui"
                                  >
                                    <Check className="size-4" />
                                  </button>
                                  <button
                                    onClick={() => handleRejectRoleRequest(request.id)}
                                    className="text-rose-600 hover:text-rose-700"
                                    title="Tolak"
                                  >
                                    <XCircle className="size-4" />
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeTab === 'users' && (
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Role</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {users
                          .filter(u => 
                            u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            u.email.toLowerCase().includes(searchQuery.toLowerCase())
                          )
                          .map((userItem) => (
                          <tr key={userItem.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4 text-sm text-slate-900">{userItem.name}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{userItem.email}</td>
                            <td className="px-6 py-4">
                              <select
                                value={userItem.role}
                                onChange={(e) => handleUpdateUserRole(userItem.id, e.target.value)}
                                className="px-3 py-1 border border-slate-300 rounded text-xs focus:ring-2 focus:ring-indigo-500 capitalize"
                              >
                                <option value="user">User</option>
                                <option value="umkm">UMKM</option>
                                <option value="admin">Admin</option>
                              </select>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-600">
                              {userItem.createdAt ? formatDate(userItem.createdAt) : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}