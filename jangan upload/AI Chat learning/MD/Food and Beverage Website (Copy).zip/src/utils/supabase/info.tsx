// Supabase disabled - Application uses localStorage
export const projectId = ""
export const publicAnonKey = ""
