// Edge function disabled
