// KV store disabled
