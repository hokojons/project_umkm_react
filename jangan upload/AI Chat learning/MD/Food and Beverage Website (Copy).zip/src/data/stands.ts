import { UMKMBusiness } from '../types';

export const foodStands: UMKMBusiness[] = [
  {
    id: '1',
    name: 'Batik Nusantara Ibu Sari',
    owner: 'Ibu Sari',
    description: 'Batik tulis dan cap berkualitas dengan motif tradisional dan modern',
    image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.9,
    category: 'Fashion',
    whatsapp: '6281234567890',
    phone: '081234567890',
    email: 'batiknusantara@email.com',
    instagram: 'batiknusantara.sari',
    products: [
      {
        id: '1-1',
        name: 'Kemeja Batik Pria',
        description: 'Batik cap motif parang, bahan katun premium',
        price: 175000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '1-2',
        name: 'Dress Batik Wanita',
        description: 'Batik tulis motif kawung, model modern',
        price: 250000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '1-3',
        name: 'Kain Batik 2 Meter',
        description: 'Kain batik cap siap jahit, berbagai motif',
        price: 150000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '1-4',
        name: 'Selendang Batik',
        description: 'Selendang batik sutra halus',
        price: 95000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '1-5',
        name: 'Masker Batik Kain',
        description: 'Masker kain batik, 3 lapis, isi 3 pcs',
        price: 35000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1761516659497-8478e39d2b26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGZhYnJpY3xlbnwxfHx8fDE3NjUzNDQyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  {
    id: '2',
    name: 'Kerajinan Anyaman Pak Joko',
    owner: 'Pak Joko',
    description: 'Produk anyaman rotan dan bambu berkualitas tinggi, cocok untuk dekorasi rumah',
    image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.8,
    category: 'Kerajinan',
    whatsapp: '6281298765432',
    phone: '081298765432',
    instagram: 'anyaman.pakjoko',
    products: [
      {
        id: '2-1',
        name: 'Keranjang Rotan Besar',
        description: 'Keranjang rotan dengan pegangan, diameter 35cm',
        price: 125000,
        category: 'craft',
        image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '2-2',
        name: 'Tas Anyaman',
        description: 'Tas anyaman rotan untuk jalan-jalan, ukuran sedang',
        price: 95000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '2-3',
        name: 'Tempat Tisu Anyaman',
        description: 'Tempat tisu kotak dari anyaman bambu',
        price: 45000,
        category: 'craft',
        image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '2-4',
        name: 'Nampan Rotan',
        description: 'Nampan rotan bulat untuk sajian, diameter 30cm',
        price: 75000,
        category: 'craft',
        image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '2-5',
        name: 'Set Tatakan Gelas',
        description: 'Tatakan gelas anyaman rotan, isi 6 pcs',
        price: 35000,
        category: 'craft',
        image: 'https://images.unsplash.com/photo-1567696154083-9547fd0c8e1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3ZlbiUyMGJhc2tldHxlbnwxfHx8fDE3NjUyNDU1OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  {
    id: '3',
    name: 'Camilan Khas Bu Ani',
    owner: 'Bu Ani',
    description: 'Jajanan tradisional dan kue kering homemade tanpa pengawet',
    image: 'https://images.unsplash.com/photo-1761050163550-2a316fa3eceb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGNvb2tpZXN8ZW58MXx8fHwxNzY1MzQ0Mjk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.9,
    category: 'Kuliner',
    whatsapp: '6281387654321',
    email: 'camilanbuani@email.com',
    instagram: 'camilan.buani',
    products: [
      {
        id: '3-1',
        name: 'Kue Kering Nastar',
        description: 'Nastar selai nanas premium, toples 500gr',
        price: 85000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1761050163550-2a316fa3eceb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGNvb2tpZXN8ZW58MXx8fHwxNzY1MzQ0Mjk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '3-2',
        name: 'Kastengel Premium',
        description: 'Kastengel keju edam asli, toples 400gr',
        price: 95000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1761050163550-2a316fa3eceb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGNvb2tpZXN8ZW58MXx8fHwxNzY1MzQ0Mjk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '3-3',
        name: 'Keripik Tempe',
        description: 'Keripik tempe renyah aneka rasa, 250gr',
        price: 25000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1738225735048-d3c9f5ad0869?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMHNuYWNrc3xlbnwxfHx8fDE3NjUzNDQyODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '3-4',
        name: 'Dodol Betawi',
        description: 'Dodol durian asli Betawi, 300gr',
        price: 45000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1738225735048-d3c9f5ad0869?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMHNuYWNrc3xlbnwxfHx8fDE3NjUzNDQyODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '3-5',
        name: 'Paket Hampers',
        description: 'Paket kue kering 4 toples mix variant',
        price: 250000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1761050163550-2a316fa3eceb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGNvb2tpZXN8ZW58MXx8fHwxNzY1MzQ0Mjk0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  {
    id: '4',
    name: 'Skincare Alami Mba Dina',
    owner: 'Mba Dina',
    description: 'Produk perawatan kulit dari bahan alami tanpa bahan kimia berbahaya',
    image: 'https://images.unsplash.com/photo-1599847935464-fde3827639c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmV8ZW58MXx8fHwxNzY1MjYzNTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.7,
    category: 'Kecantikan',
    whatsapp: '6281456789012',
    email: 'skincarealami.dina@email.com',
    instagram: 'skincare.mbadina',
    products: [
      {
        id: '4-1',
        name: 'Face Wash Natural',
        description: 'Sabun cuci muka dari green tea dan aloe vera',
        price: 45000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1599847935464-fde3827639c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmV8ZW58MXx8fHwxNzY1MjYzNTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '4-2',
        name: 'Toner Rice Water',
        description: 'Toner dari air beras fermentasi, 100ml',
        price: 35000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1599847935464-fde3827639c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmV8ZW58MXx8fHwxNzY1MjYzNTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '4-3',
        name: 'Serum Vitamin C',
        description: 'Serum brightening vitamin C murni, 30ml',
        price: 85000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1590156221187-1710315f710b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWF1dHklMjBjb3NtZXRpY3N8ZW58MXx8fHwxNzY1MzI1MjAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '4-4',
        name: 'Masker Sheet Honey',
        description: 'Masker wajah madu asli, isi 5 sheet',
        price: 50000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1599847935464-fde3827639c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmV8ZW58MXx8fHwxNzY1MjYzNTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '4-5',
        name: 'Paket Glowing Skin',
        description: 'Paket lengkap skincare routine 4 produk',
        price: 175000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1590156221187-1710315f710b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWF1dHklMjBjb3NtZXRpY3N8ZW58MXx8fHwxNzY1MzI1MjAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  {
    id: '5',
    name: 'Tas Kanvas Kreatif Mas Rian',
    owner: 'Mas Rian',
    description: 'Tas kanvas custom dan totebag dengan desain unik dan personal',
    image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.8,
    category: 'Fashion',
    whatsapp: '6281567890123',
    phone: '081567890123',
    instagram: 'kanvaskreatif.rian',
    products: [
      {
        id: '5-1',
        name: 'Tote Bag Polos',
        description: 'Tote bag kanvas natural ukuran L',
        price: 35000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '5-2',
        name: 'Tote Bag Custom Print',
        description: 'Tote bag dengan print design custom sesuai permintaan',
        price: 55000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '5-3',
        name: 'Tas Ransel Kanvas',
        description: 'Ransel kanvas dengan laptop slot',
        price: 125000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '5-4',
        name: 'Sling Bag Mini',
        description: 'Tas selempang kecil dari kanvas tebal',
        price: 65000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '5-5',
        name: 'Pouch Serba Guna',
        description: 'Pouch kanvas kecil untuk kosmetik/gadget',
        price: 25000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1574365569389-a10d488ca3fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RlJTIwYmFnfGVufDF8fHx8MTc2NTI5NzY1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  {
    id: '6',
    name: 'Aksesoris Handmade Mba Putri',
    owner: 'Mba Putri',
    description: 'Perhiasan dan aksesoris handmade dari bahan berkualitas dengan desain elegan',
    image: 'https://images.unsplash.com/photo-1573227890085-12ab5d68a170?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2Vscnl8ZW58MXx8fHwxNzY1MzMxODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rating: 4.9,
    category: 'Aksesoris',
    whatsapp: '6281678901234',
    email: 'handmade.putri@email.com',
    instagram: 'aksesoris.putri',
    products: [
      {
        id: '6-1',
        name: 'Anting Clay Minimalis',
        description: 'Anting clay handmade dengan desain modern',
        price: 35000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1573227890085-12ab5d68a170?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2Vscnl8ZW58MXx8fHwxNzY1MzMxODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '6-2',
        name: 'Kalung Manik-manik',
        description: 'Kalung dari manik kaca dengan liontin unik',
        price: 55000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1573227890085-12ab5d68a170?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2Vscnl8ZW58MXx8fHwxNzY1MzMxODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '6-3',
        name: 'Gelang Tasbih',
        description: 'Gelang tasbih kayu dengan ukiran halus',
        price: 45000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1573227890085-12ab5d68a170?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2Vscnl8ZW58MXx8fHwxNzY1MzMxODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '6-4',
        name: 'Bros Hijab Premium',
        description: 'Bros hijab dengan kristal dan mutiara',
        price: 40000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1675929112281-7fad4e8b0687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGFjY2Vzc29yaWVzfGVufDF8fHx8MTc2NTI0OTgxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: '6-5',
        name: 'Set Perhiasan Pesta',
        description: 'Set anting, kalung, dan gelang untuk acara spesial',
        price: 150000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1573227890085-12ab5d68a170?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2Vscnl8ZW58MXx8fHwxNzY1MzMxODQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]
  },
  // Kategori UMKM - Multi-produk campuran
  {
    id: '7',
    name: 'UMKM Berkah Sejahtera',
    owner: 'Bu Yanti',
    description: 'UMKM lokal dengan berbagai produk handmade dan kuliner khas daerah',
    about: 'UMKM Berkah Sejahtera dimulai dari rumahan sejak 2018. Kami memproduksi berbagai produk handmade dan kuliner yang dikembangkan bersama ibu-ibu PKK di kampung kami. Visi kami adalah memberdayakan ekonomi keluarga melalui produk berkualitas dengan harga terjangkau.',
    image: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFsbCUyMGJ1c2luZXNzJTIwc2hvcHxlbnwxfHx8fDE3MzQ1Njc4OTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    category: 'UMKM',
    whatsapp: '6281789012345',
    phone: '081789012345',
    email: 'berkahsejahtera@email.com',
    instagram: 'berkahsejahtera.umkm',
    products: [
      {
        id: '7-1',
        name: 'Sambal Ijo Homemade',
        description: 'Sambal ijo pedas segar, tanpa pengawet, 250ml',
        price: 25000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1639744091314-f6bbef87a5f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc2FtYmFsfGVufDF8fHx8MTczNDU2Nzk5MHww&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '7-2',
        name: 'Tas Rajut Tangan',
        description: 'Tas rajut tangan dari benang premium, berbagai warna',
        price: 75000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcm9jaGV0JTIwYmFnfGVufDF8fHx8MTczNDU2ODEyMHww&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '7-3',
        name: 'Abon Sapi Asli',
        description: 'Abon sapi murni tanpa campuran, 250gr',
        price: 60000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwZm9vZHxlbnwxfHx8fDE3MzQ1NjgyNjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '7-4',
        name: 'Sandal Rajut Nyaman',
        description: 'Sandal rajut handmade untuk di rumah',
        price: 35000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1603487742131-4160ec999306?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbGlwcGVyc3xlbnwxfHx8fDE3MzQ1NjgzMjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '7-5',
        name: 'Keripik Singkong Pedas',
        description: 'Keripik singkong renyah dengan bumbu pedas manis, 200gr',
        price: 20000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1621939514649-280e2ee25f60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlwc3xlbnwxfHx8fDE3MzQ1NjgzODB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      }
    ]
  },
  {
    id: '8',
    name: 'Kreasi Nusantara Pak Budi',
    owner: 'Pak Budi',
    description: 'UMKM yang fokus pada produk kerajinan dan fashion lokal berkualitas tinggi',
    about: 'Saya Pak Budi, pengrajin dan penjahit lokal yang sudah berkecimpung di dunia fashion sejak 1995. Kreasi Nusantara lahir dari kecintaan saya terhadap budaya Indonesia. Setiap produk dibuat dengan penuh cinta dan kehati-hatian untuk menghadirkan kualitas terbaik bagi pelanggan.',
    image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb2NhbCUyMG1hcmtldHxlbnwxfHx8fDE3MzQ1Njg1MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    category: 'UMKM',
    whatsapp: '6281890123456',
    phone: '081890123456',
    email: 'kreasinus antara.budi@email.com',
    instagram: 'kreasinus.pakbudi',
    products: [
      {
        id: '8-1',
        name: 'Sepatu Tenun Ikat',
        description: 'Sepatu casual dari tenun ikat asli NTT',
        price: 185000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1560343090-f0409e92791a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaG9lc3xlbnwxfHx8fDE3MzQ1Njg1NjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '8-2',
        name: 'Sarung Tenun Premium',
        description: 'Sarung tenun tangan motif khas, 100% katun',
        price: 225000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWJyaWN8ZW58MXx8fHwxNzM0NTY4NjIwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '8-3',
        name: 'Dompet Kulit Asli',
        description: 'Dompet kulit sapi asli handmade dengan jahitan rapi',
        price: 95000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwd2FsbGV0fGVufDF8fHx8MTczNDU2ODY4MHww&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '8-4',
        name: 'Ikat Pinggang Kulit',
        description: 'Ikat pinggang kulit asli dengan buckle vintage',
        price: 125000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1624222247344-550fb60583bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwYmVsdHxlbnwxfHx8fDE3MzQ1Njg3NDB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '8-5',
        name: 'Topi Rajut Wool',
        description: 'Topi rajut dari wool hangat untuk musim hujan',
        price: 55000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29sJTIwaGF0fGVufDF8fHx8MTczNDU2ODgwMHww&ixlib=rb-4.1.0&q=80&w=1080'
      }
    ]
  },
  {
    id: '9',
    name: 'Dapur Mama Sinta',
    owner: 'Mama Sinta',
    description: 'UMKM kuliner dengan berbagai olahan frozen food dan makanan siap saji berkualitas',
    about: 'Dapur Mama Sinta adalah bisnis rumahan yang saya mulai tahun 2020 di tengah pandemi. Dari dapur kecil, saya membuat berbagai frozen food dan makanan siap saji untuk membantu ibu-ibu yang sibuk. Semua produk dibuat fresh to order dengan bahan pilihan tanpa MSG berlebihan.',
    image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob21lJTIwa2l0Y2hlbnxlbnwxfHx8fDE3MzQ1Njg5MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    category: 'UMKM',
    whatsapp: '6281901234567',
    email: 'dapurmamasinta@email.com',
    instagram: 'dapur.mamasinta',
    products: [
      {
        id: '9-1',
        name: 'Dimsum Ayam Isi 10',
        description: 'Dimsum ayam homemade fresh frozen, isi 10pcs',
        price: 35000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaW1zdW18ZW58MXx8fHwxNzM0NTY4OTYwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '9-2',
        name: 'Nugget Sayur Sehat',
        description: 'Nugget sayuran untuk anak, tanpa MSG, 250gr',
        price: 28000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1625944525533-473f1a3d54e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudWdnZXRzfGVufDF8fHx8MTczNDU2OTAyMHww&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '9-3',
        name: 'Risoles Mayo Isi 6',
        description: 'Risoles ragout ayam dengan mayonaise, isi 6pcs',
        price: 30000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc25hY2t8ZW58MXx8fHwxNzM0NTY5MDgwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '9-4',
        name: 'Samosa Kentang Isi 8',
        description: 'Samosa kentang bumbu kari, isi 8pcs',
        price: 25000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2F8ZW58MXx8fHwxNzM0NTY5MTQwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '9-5',
        name: 'Paket Frozen Food Mix',
        description: 'Paket hemat isi dimsum, nugget, risoles, dan samosa',
        price: 100000,
        category: 'food',
        image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaW1zdW18ZW58MXx8fHwxNzM0NTY4OTYwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      }
    ]
  },
  {
    id: '10',
    name: 'Eco Product Indonesia',
    owner: 'Kak Dimas',
    description: 'UMKM ramah lingkungan dengan produk eco-friendly untuk gaya hidup sustainable',
    about: 'Eco Product Indonesia didirikan tahun 2019 dengan misi mengurangi penggunaan plastik sekali pakai. Kami menyediakan berbagai produk ramah lingkungan yang stylish dan fungsional. Setiap pembelian produk kami berarti Anda berkontribusi dalam menjaga bumi untuk generasi mendatang.',
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY28lMjBwcm9kdWN0c3xlbnwxfHx8fDE3MzQ1NjkyNDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    category: 'UMKM',
    whatsapp: '6282012345678',
    phone: '082012345678',
    email: 'ecoproduct.indonesia@email.com',
    instagram: 'ecoproduct.id',
    products: [
      {
        id: '10-1',
        name: 'Tumbler Bambu 500ml',
        description: 'Tumbler dari bambu natural dengan insulasi ganda',
        price: 85000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW1ib28lMjBib3R0bGV8ZW58MXx8fHwxNzM0NTY5MzAwfDA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '10-2',
        name: 'Sedotan Stainless Isi 4',
        description: 'Sedotan stainless reusable dengan sikat pembersih',
        price: 25000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1600857545015-bafc0fed2a6d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFpbmxlc3MlMjBzdHJhd3xlbnwxfHx8fDE3MzQ1NjkzNjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '10-3',
        name: 'Tas Belanja Kanvas Jumbo',
        description: 'Tas belanja kanvas tebal anti air, ukuran jumbo',
        price: 45000,
        category: 'accessory',
        image: 'https://images.unsplash.com/photo-1547949003-9792a18a2601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW52YXMlMjBzaG9wcGluZyUyMGJhZ3xlbnwxfHx8fDE3MzQ1Njk0MjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '10-4',
        name: 'Lunch Box Stainless 3 Sekat',
        description: 'Kotak makan stainless 3 sekat kedap udara',
        price: 75000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1600857544200-e3b0e1b6c1da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdW5jaCUyMGJveHxlbnwxfHx8fDE3MzQ1Njk0ODB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      },
      {
        id: '10-5',
        name: 'Sabun Cuci Piring Organik',
        description: 'Sabun cuci piring dari bahan organik, 500ml',
        price: 35000,
        category: 'product',
        image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmdhbmljJTIwc29hcHxlbnwxfHx8fDE3MzQ1Njk1NDB8MA&ixlib=rb-4.1.0&q=80&w=1080'
      }
    ]
  }
];