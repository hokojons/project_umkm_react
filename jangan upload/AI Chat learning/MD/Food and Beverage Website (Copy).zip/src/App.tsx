import { useState, useRef, useEffect } from 'react';
import { Store, ShoppingCart, Search, User as UserIcon, Settings, LogOut, Award, PlusCircle, Package, UserCircle, Moon, Sun } from 'lucide-react';
import { Toaster } from 'sonner@2.0.3';
import { StandCard } from './components/StandCard';
import { MenuModal } from './components/MenuModal';
import { CartSidebar } from './components/CartSidebar';
import { HeroSection } from './components/HeroSection';
import { FeaturedSection } from './components/FeaturedSection';
import { SpecialPackagesSection } from './components/SpecialPackagesSection';
import { EventList } from './components/EventList';
import { EventApplicationModal } from './components/EventApplicationModal';
import { UMKMDashboard } from './components/UMKMDashboard';
import { LoginModal } from './components/LoginModal';
import { AdminPanel } from './components/AdminPanel';
import { SubmitBusinessModal } from './components/SubmitBusinessModal';
import RoleUpgradeModal from './components/RoleUpgradeModal';
import { OrderHistoryModal } from './components/OrderHistoryModal';
import { ProfileModal } from './components/ProfileModal';
import { CartProvider, useCart } from './context/CartContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { foodStands } from './data/stands';
import { FoodStand } from './types';

function AppContent() {
  const [selectedStand, setSelectedStand] = useState<FoodStand | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);
  const [isRoleUpgradeOpen, setIsRoleUpgradeOpen] = useState(false);
  const [isUMKMDashboardOpen, setIsUMKMDashboardOpen] = useState(false);
  const [isEventApplicationOpen, setIsEventApplicationOpen] = useState(false);
  const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [stands, setStands] = useState<FoodStand[]>(foodStands);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const standsRef = useRef<HTMLDivElement>(null);
  const { getTotalItems } = useCart();
  const { user, signOut, isLoading } = useAuth();

  // Dynamic categories based on available stands
  const categories = ['All', ...Array.from(new Set(stands.map(stand => stand.category)))].filter(cat => {
    if (cat === 'All') return true;
    return stands.some(stand => stand.category === cat);
  });

  // Load dark mode preference
  useEffect(() => {
    const savedDarkMode = localStorage.getItem('pasar_umkm_dark_mode');
    if (savedDarkMode === 'true') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  // Load businesses from localStorage
  useEffect(() => {
    loadBusinesses();
  }, []);

  const loadBusinesses = () => {
    // Load from localStorage
    const localBusinesses = localStorage.getItem('pasar_umkm_businesses');
    const localProducts = localStorage.getItem('pasar_umkm_products');

    if (localBusinesses && localProducts) {
      const businesses = JSON.parse(localBusinesses);
      const products = JSON.parse(localProducts);

      // Attach products to businesses
      const businessesWithProducts = businesses.map((business: any) => {
        const businessProducts = products.filter((p: any) => p.businessId === business.id);
        return { ...business, products: businessProducts };
      });

      // Merge with default stands
      const mergedStands = [...foodStands];
      businessesWithProducts.forEach((business: any) => {
        const existingIndex = mergedStands.findIndex(s => s.id === business.id);
        if (existingIndex >= 0) {
          mergedStands[existingIndex] = business;
        } else {
          mergedStands.push(business);
        }
      });
      setStands(mergedStands);
    }
  };

  const filteredStands = stands.filter(stand => {
    const matchesSearch = stand.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         stand.owner.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         stand.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || stand.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const scrollToStands = () => {
    standsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
  };

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    localStorage.setItem('pasar_umkm_dark_mode', newDarkMode.toString());
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors">
      <Toaster position="top-center" richColors />
      
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40 transition-colors">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 dark:bg-indigo-500 p-2 rounded-lg transition-colors">
                <Store className="size-6 text-white" />
              </div>
              <h1 className="text-indigo-600 dark:text-indigo-400 hidden sm:block transition-colors">Pasar UMKM</h1>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-xl relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400 dark:text-gray-500" />
              <input
                type="text"
                placeholder="Cari produk UMKM atau pemilik usaha..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 transition-colors"
              />
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-2">
              <button 
                onClick={toggleDarkMode}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
                title={isDarkMode ? "Light Mode" : "Dark Mode"}
              >
                {isDarkMode ? (
                  <Sun className="size-5 text-gray-700 dark:text-gray-300" />
                ) : (
                  <Moon className="size-5 text-gray-700 dark:text-gray-300" />
                )}
              </button>
              
              <button 
                onClick={() => setIsCartOpen(true)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors relative"
              >
                <ShoppingCart className="size-5 text-gray-700 dark:text-gray-300" />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-1 -right-1 bg-indigo-600 dark:bg-indigo-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {getTotalItems()}
                  </span>
                )}
              </button>
              
              {!isLoading && (
                user ? (
                  <div className="relative">
                    <button 
                      onClick={() => setShowUserMenu(!showUserMenu)}
                      className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors flex items-center gap-2"
                    >
                      <UserIcon className="size-5 text-gray-700 dark:text-gray-300" />
                      <span className="hidden sm:inline text-gray-900 dark:text-gray-100">{user.name}</span>
                    </button>
                    
                    {showUserMenu && (
                      <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2 transition-colors">
                        <div className="px-4 py-2 border-b border-gray-200 dark:border-gray-700">
                          <p className="text-sm text-gray-900 dark:text-gray-100">{user.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">{user.email}</p>
                          {user.role === 'admin' && (
                            <span className="inline-block mt-1 px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-xs rounded">
                              Admin
                            </span>
                          )}
                          {user.role === 'umkm' && (
                            <span className="inline-block mt-1 px-2 py-0.5 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 text-xs rounded">
                              Penjual UMKM
                            </span>
                          )}
                        </div>
                        
                        {user.role === 'umkm' && (
                          <button
                            onClick={() => {
                              setIsSubmitOpen(true);
                              setShowUserMenu(false);
                            }}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                          >
                            <PlusCircle className="size-4" />
                            Ajukan Toko UMKM
                          </button>
                        )}
                        
                        {user.role === 'user' && (
                          <button
                            onClick={() => {
                              setIsRoleUpgradeOpen(true);
                              setShowUserMenu(false);
                            }}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                          >
                            <Award className="size-4" />
                            Request Role UMKM
                          </button>
                        )}
                        
                        {user.role === 'umkm' && (
                          <button
                            onClick={() => {
                              setIsUMKMDashboardOpen(true);
                              setShowUserMenu(false);
                            }}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                          >
                            <Settings className="size-4" />
                            Dashboard UMKM
                          </button>
                        )}
                        
                        {user.role === 'admin' && (
                          <button
                            onClick={() => {
                              setIsAdminOpen(true);
                              setShowUserMenu(false);
                            }}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                          >
                            <Settings className="size-4" />
                            Admin Panel
                          </button>
                        )}
                        
                        <button
                          onClick={() => {
                            setIsOrderHistoryOpen(true);
                            setShowUserMenu(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                        >
                          <Package className="size-4" />
                          Riwayat Pesanan
                        </button>
                        
                        <button
                          onClick={() => {
                            setIsProfileOpen(true);
                            setShowUserMenu(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-gray-900 dark:text-gray-100"
                        >
                          <UserCircle className="size-4" />
                          Profile Saya
                        </button>
                        
                        <button
                          onClick={handleSignOut}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-red-600 dark:text-red-400 border-t border-gray-200 dark:border-gray-700 mt-2"
                        >
                          <LogOut className="size-4" />
                          Keluar
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <button 
                    onClick={() => setIsLoginOpen(true)}
                    className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors flex items-center gap-2"
                  >
                    <UserIcon className="size-5 text-gray-700 dark:text-gray-300" />
                    <span className="hidden sm:inline text-gray-900 dark:text-gray-100">Masuk</span>
                  </button>
                )
              )}
            </div>
          </div>

          {/* Category Pills - Below search on mobile */}
          {categories.length > 1 && (
            <div className="flex gap-2 overflow-x-auto mt-4 pb-2 hide-scrollbar">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors text-sm ${
                    selectedCategory === category
                      ? 'bg-indigo-600 dark:bg-indigo-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <HeroSection onExplore={scrollToStands} />

      {/* Featured Section */}
      <FeaturedSection />

      {/* Special Packages Section */}
      <SpecialPackagesSection />

      {/* Event List Section */}
      <EventList 
        onApplyToEvent={(eventId) => {
          if (!user) {
            setIsLoginOpen(true);
            return;
          }
          setSelectedEventId(eventId);
          setIsEventApplicationOpen(true);
        }}
        showApplyButton={!!user}
        userRole={user?.role}
        isLoggedIn={!!user}
      />

      {/* All Stands Section */}
      <section ref={standsRef} className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h2 className="mb-2 text-gray-900 dark:text-gray-100">Semua Produk UMKM</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Menampilkan {filteredStands.length} UMKM {selectedCategory !== 'All' && `kategori ${selectedCategory}`}
          </p>
        </div>
        
        {filteredStands.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">Tidak ada UMKM yang ditemukan</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStands.map((stand) => (
              <StandCard
                key={stand.id}
                stand={stand}
                onClick={() => setSelectedStand(stand)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Menu Modal */}
      {selectedStand && (
        <MenuModal
          stand={selectedStand}
          onClose={() => setSelectedStand(null)}
        />
      )}

      {/* Cart Sidebar */}
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      
      {/* Login Modal */}
      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
      
      {/* Admin Panel */}
      <AdminPanel 
        isOpen={isAdminOpen} 
        onClose={() => setIsAdminOpen(false)}
        onDataUpdate={loadBusinesses}
      />
      
      {/* Submit Product Modal */}
      {user && (
        <SubmitBusinessModal 
          isOpen={isSubmitOpen} 
          onClose={() => setIsSubmitOpen(false)}
        />
      )}
      
      {/* Role Upgrade Modal */}
      {user && isRoleUpgradeOpen && (
        <RoleUpgradeModal 
          onClose={() => setIsRoleUpgradeOpen(false)}
        />
      )}
      
      {/* UMKM Dashboard */}
      {user && isUMKMDashboardOpen && (
        <UMKMDashboard 
          isOpen={isUMKMDashboardOpen}
          onClose={() => setIsUMKMDashboardOpen(false)}
          onDataUpdate={loadBusinesses}
        />
      )}
      
      {/* Event Application Modal */}
      {user && isEventApplicationOpen && (
        <EventApplicationModal 
          isOpen={isEventApplicationOpen}
          eventId={selectedEventId}
          onClose={() => setIsEventApplicationOpen(false)}
        />
      )}
      
      {/* Order History Modal */}
      <OrderHistoryModal 
        isOpen={isOrderHistoryOpen}
        onClose={() => setIsOrderHistoryOpen(false)}
      />
      
      {/* Profile Modal */}
      {user && (
        <ProfileModal 
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}