
  # Food and Beverage Website (Copy)

  This is a code bundle for Food and Beverage Website (Copy). The original project is available at https://www.figma.com/design/6wMOrO0Gd7mBlVp71ol2T2/Food-and-Beverage-Website--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  